function change(i) {
	var src = document.getElementById('preview-coverflow').getElementsByTagName('img')[i].src;
	src = src.replace( /.*\//, '' ).replace( /\..*/, '') ;
	document.getElementById('slideName').innerHTML = src;
}
var first=0;

change(first);

// http://www.jqueryscript.net/animation/Powerful-jQuery-Plugin-For-Cover-Flow-Effect-Vanderlee-Coverflow.html
$(function() {
	if ($.fn.reflect) {
	//	$('#preview-coverflow .cover').reflect({height:0.2,opacity:1.0});	// only possible in very specific situations
	}

	$('#preview-coverflow').coverflow({
		index:			first,
		density:		2,
		innerOffset:	160,
		// innerAngle:     -75,
		// outerAngle:     30,
		innerScale:		.3,
		duration:       'slow',
		change : function(e) {
			try {
			  var i = e.target.__coverflow_frame ;

			  if (i) change(i);
			} catch(e) { }
		},
		animateStep:	function(event, cover, offset, isVisible, isMiddle, sin, cos) {
			if (isVisible) {
				if (isMiddle) {
					$(cover).css({
						'filter':			'none',
						'-webkit-filter':	'none'
					});
				} else {
					var brightness	= 1 + Math.abs(sin),
						contrast	= 1 - Math.abs(sin),
						filter		= 'contrast('+contrast+') brightness('+brightness+')';
					$(cover).css({
						'filter':			filter,
						'-webkit-filter':	filter
					});
				}
			}
		}
	});
});
