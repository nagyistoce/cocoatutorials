    // cursor position = x,y
    var y  =  0 ;
    var x  =  0 ;

    // which browser?
    var n4 = (document.layers) ;
    var n6 = (document.getElementById && !document.all) ;
    var ie = (document.all) ;
    var o6 = navigator.appName.indexOf("Opera") >= 0 ;

    if ( false ) {
      n4 = n4 ? true : false ;
      n6 = n6 ? true : false ;
      ie = ie ? true : false ;
      o6 = o6 ? true : false ;
      var lf = ' \n ' ;
      alert( 'n4 = ' + n4 + lf
           + 'n6 = ' + n6 + lf 
           + 'ie = ' + ie + lf
           + 'o6 = ' + o6 + lf
           ) ;
    }

    function abs(x) { return x >= 0 ? x : -x ; }

    function fixup(s)
    {
        var p  = '' ;
        var a  = "'"   ;
        var b  = "\\'" ;
        for ( var i = 0 ; i < s.length ; i++ ) {
          var  c = "" + s.substr(i,1) ;
          if ( c == a ) p += b ;
          else          p += c ;
        }
        return p ;
    }

    function mouse_nn(e)
    {
        y = e.pageY - window.pageYOffset ;
        x = e.pageX ;
        mouseMove() ;
        e.preventDefault(true) ;
        e.cancelBubble = true  ;
        return true ;
    }

    function mouse_ie()
    {
        var e  = window.event ;
        e.cancelBubble = true ;
        y = ie ? event.clientY : event.clientY - window.pageYOffset ;
        x = event.clientX;
        mouseMove() ;
        return false ;
    }

    if (n4||n6)
    {
        window.captureEvents(Event.MOUSEMOVE);
        if (n4 ) {
          window.onMouseDown   = mouse_nn ;
          window.onMouseUp     = mouse_nn ;
          window.onMouseMove   = mouse_nn ;
        } else {
          document.onmousedown = mouse_nn ;
          document.onmouseup   = mouse_nn ;
          document.onmousemove = mouse_nn ;
        }
    }

    if (ie||o6){
        document.onmousemove   = mouse_ie ;
    }

    //  drag'n'drop stuff
    var gz      =  100  ; // global z-index
    var gp      =  "x1" ; // current picture
    var bDown   = false ; // state of the mouse
    var X       = 0     ; // x at start of move
    var Y       = 0     ; // y at start of move
    var L       = 0     ; // Start Left
    var T       = 0     ; // Start Top
    var P               ; // which picture is moving
    var timeout = 0     ; // timer object
    var fast    = 2000  ; // sleep (milliseconds)
    var nThis   = 0     ; // current timed picture

    var oWidth  = 0     ; // old Width
    var oHeight = 0     ; // old Height
    var oPhoto  = 0     ; // old Photo URL

    var bOnce   = true  ; // debugging flag

    var bTitles = true  ; // enable/disable titles

    function seT(p,P)
    {
        var result ;
        try {
       // alert("document.getElementById('" + p +"')" + P)
          result = eval("document.getElementById('" + p +"')" + P) ;
        } catch ( e ) {} ;
        return result ;
    }

    function set(p,P)
    {
        var result ;
        try {
          result = eval("document." + p + P) ;
        } catch ( e ) {
          result = seT(p,P) ;
        } ;
        return result ;
    }

    function highlight(p)
    {
        set(gp , ".style.border      ='solid wheat 8px;'" ) ;
        set(gp , ".style.borderTop   ='solid wheat 38px;'") ;
        if ( oWidth && oHeight ) {
          set(gp,".src   ='" + fixup(oPhoto) + "'" ) ;
        }
        gp = p  ;

        if ( timeout ) {
          oWidth  = set(p,".width"  ) ;
          oHeight = set(p,".height" ) ;
          oPhoto  = set(p,".src"    ) ;
          var pp  = oPhoto.replace("Thumbs/","Images/") ;
          set(p,".src='" + fixup(pp) + "'") ;

          var cx  = parseInt(set(p,".style.left")) ;
          var cy  = parseInt(set(p,".style.top"))  ;

          window.scroll(cx,cy) ;

        } else {
          oWidth  = 0 ;
          oHeight = 0 ;
        }

        set( p , ".style.zIndex=" + (++gz)                ) ;
        set( p , ".style.border='solid white 8px;'"       ) ;
        set( p , ".style.borderTop   ='solid white 38px;'") ;
      //set( p , ".style.filter.alpha.opacity=50") ;
      //if ( timeout ) {
      //  set( p , ".style.MozOpacity=0.50;") ;
      //}
        if ( bTitles ) {
          var s = "t" + p.substr(1) ;
          set(s , ".style.zIndex=" + (++gz)  ) ;
        }
    }

    function mouseOver(p)
    {
        if ( !bDown && !timeout ) {
          highlight(p) ;
          nThis = p.substr(1) ;
        }
    }

    function mouseDown(p)
    {
        bDown  = true ;
        X      = x    ;
        Y      = y    ;
        P      = p    ;
        L      = parseInt(set(p,".style.left")) ;
        T      = parseInt(set(p,".style.top ")) ;
    }

    function click(p)
    {
        if ( timeout ) Stop() ;
        else {
          var oPhoto  = set(p,".src"    ) ;
          var pp ;
          if ( oPhoto.indexOf("Thumbs/") != -1 ) {
            pp  = oPhoto.replace("Thumbs/","Images/") ;
          } else {
            pp  = oPhoto.replace("Images/","Thumbs/") ;
          }

          set(p,".src='" + fixup(pp) + "'") ;
          set(p, ".style.zIndex=" + (++gz)  ) ;

          var s = "t" + p.substr(1) ;
          set(s , ".style.zIndex=" + (++gz)  ) ;
        }
    }

    function mouseUp(p)
    {
        if ( bDown ) {
          var dx = abs(x-X)    ;
          var dy = abs(y-Y)    ;
          if ( (dx+dy) < 4 ) click(p) ;
        }
        bDown = false ;
    }

    function mouseMove()
    {
        if ( bDown ) {
          var l = L+x-X    ;
          var t = T+y-Y    ;
          set(P, ".style.left = " + l) ;
          set(P, ".style.top  = " + t) ;
          if ( bTitles ) {
            var s = "t" + P.substr(1)    ;
            set(s, ".style.left = " + (l+10)) ;
            set(s, ".style.top  = " + (t+10)) ;
          }
        }
    }

    function theTitle(i)
    {
        var r = unescape(photos[i]) ;
        var e;
        try {
        	var R = unescape(captions[i]);
        	if ( R != 'None' ) r=R;
        } catch(e) {} ;
        if ( r.lastIndexOf("/") != -1 ) {
          r = r.substr(r.lastIndexOf("/")+1) ;
        }
        if ( r.lastIndexOf(".") != -1 ) {
          r = r.substr(0,r.lastIndexOf(".")) ;
        }
        while ( r.indexOf(' ') != -1 ) {
          r = r.replace(" ","&nbsp;") ;
        }
        return r ;
    }

    function println(s) { document.write(s+"\n") ; }
    function Println(s) { println(s) ; if ( bOnce ) alert(s) ; bOnce = false ; }

    function theDoc(nPhotos,nColPixels,nRowPixels,nColRandom,nRowRandom)
    {
        println("<table>") ;
        var bTrailer = false ;
        var nRow     = 0     ;
        var nCol     = 0     ;
        for ( var i = 0 ; i < photos.length ; i++ ) {
          if ( (i % nPhotos) == 0 ) {
             println("<tr>") ;
             bTrailer = true ;
          }

          var n = "'x" + i + "'" ;
          println( "<td><img name=" + n
                 + " galleryimg = 'no' src=\"" + photos[i] + "\""
                 + " onMouseover=\"mouseOver(" + n +");\""
                 + " onMousedown=\"mouseDown(" + n +");\""
                 + " onMouseup=\"mouseUp("     + n +");\""
                 + " style=\"border:solid wheat 8px;border-top:solid wheat 38px;left:0px;top:0px;"
                 + " position:absolute;z-index:0;\"></td>"
                 ) ;


          nCol ++ ;
          if ( ((i+1)%nPhotos)== 0 ) {
            nRow ++          ;
            nCol = 0         ;
            println("</tr>") ;
            bTrailer = false ;
          }
        }
        if ( bTrailer ) println("</tr>") ;
        println("</table>") ;

        for ( var i = 0 ; i < photos.length ; i++ ) {
          if ( bTitles ) {
            var n = '"t' + i + '"' ;
            println( "<p id=" + n
                 + " style=\"left:100px;top:100px;color:red;"
                 + " position:absolute;z-index:1000;\">"
                 + theTitle(i)
                 + " </p>"
                 ) ;
          }
        }

        Arrange(nPhotos,nColPixels,nRowPixels,nColRandom,nRowRandom);
    }

    function Arrange(nPhotos,nColPixels,nRowPixels,nColRandom,nRowRandom)
    {
        var nRow     = 0 ;
        var nCol     = 0 ;
        var bRandom  = nColPixels == 0 || nRowPixels == 0 ;

        for ( i = 0 ; i < photos.length ; i++ )
        {
          var l = nCol * nColPixels + Math.round(Math.random()* nColRandom) ;
          var t = nRow * nRowPixels + Math.round(Math.random()* nRowRandom) ;
          var n = "x" + i  ;
          set(n,".style.top="    + t    ) ;
          set(n,".style.left="   + l    ) ;
          set(n,".style.zIndex=" + (gz++) ) ;

          if ( bTitles ) {
            n = "t" + i ;
            set(n,".style.left="   + (l+10) ) ;
            set(n,".style.top="    + (t+10) ) ;
            set(n,".style.zIndex=" + (gz++) ) ;
          }

          nCol ++ ;
          if ( ((i+1)%nPhotos ) == 0 ) {
            nRow ++          ;
            nCol = 0         ;
          }
        }
    }

    function nextImage()
    {
        var bStopping = false ;

        if ( nThis >= photos.length ) {
          bStopping = true ;
          nThis = 0 ;
        }

        highlight("x" + nThis) ;

        if ( bStopping )   Stop()   ;
        else               nThis ++ ;
    }

    function Stop()
    {
        if ( timeout ) {
          window.clearTimeout(timeout) ;
          timeout  = 0  ;
          Small()       ;
        }
        //window.focus(1) ;
    }

	function Stop2(newLocation)
	{
	//	alert("Stop2 " + newLocation) ;
		try {
			window.stop() ; // stop loading (needed for Safari)
		} catch ( e ) {} ;
		location = newLocation ;
	}

    function changePhotos(first,second)
    {
        if ( !timeout ) {
          for ( var i = 0 ; i < photos.length ; i++ ) {
            var  x       = "x" + i ;
            var  oPhoto  = set(x,".src"    ) ;
            if ( oPhoto.indexOf(first) >= 0 ) {
              var pp  = oPhoto.replace(first,second) ;
              set(x,".src='" + fixup(pp) + "'") ;
            }
          }
        }
    }

    function Small() { changePhotos("Images/","Thumbs/") ;  }
    function Large() { changePhotos("Thumbs/","Images/") ;  }

    function Run()
    {
        Small() ;
        if (  nThis > photos.length ) nThis = 0 ;
        if ( !timeout ) {
          timeout = window.setInterval("nextImage()",fast) ;
        }
        if ( nThis == 1 ) nThis -- ;
        nextImage() ;
        //window.focus(2) ;
    }

